Spin-orbit splitting test, see the corresponding tutorial.
