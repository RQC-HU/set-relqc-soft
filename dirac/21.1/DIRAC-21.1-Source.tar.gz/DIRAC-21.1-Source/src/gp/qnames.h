!
! Common used variables for qpack.F
!
!
      INTEGER MXQLVL
      PARAMETER (MXQLVL = 100)
!     ... keep this length in "qpack.F" as well
      CHARACTER*30 QNAMES(MXQLVL)
      COMMON /QSTACC/ QNAMES


