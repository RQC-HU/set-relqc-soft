!*** 1-dimensional plot of Becke weigths***
      REAL*8 DSTEP
      INTEGER IPWT1
      COMMON /CBBWT1/ DSTEP, IPWT1


