#if defined (SYS_CONVEX)
C$DIR PREFER_VECTOR
#else
Cvectorization note --> prefer vectorization over this loop
#endif
