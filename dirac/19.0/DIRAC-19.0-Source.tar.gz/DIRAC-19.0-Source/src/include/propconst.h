!
! FILE    : propconst.h
!
!     Collection of constants and conversion factors for
!     various property calculations
!
!       Timo Fleig      April 5, 2016
C
      REAL*8 EFAUMKSA
      PARAMETER (EFAUMKSA = 5.142206707 D00)
C
CTF   electric field e/a_0^2 in MKSA units GV/cm
CTF   Reference: NIST CODATA*, retrieved April 5, 2016
C
C
C     *http://physics.nist.gov/cgi-bin/cuu/Value?auefld
