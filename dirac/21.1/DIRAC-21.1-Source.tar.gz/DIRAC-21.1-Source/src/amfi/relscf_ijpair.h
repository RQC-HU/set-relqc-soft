      COMMON /IJPAIR/ IDK(MXB+1)                                        
