See the corresponding DIRAC web-tutorial.
