      INTEGER ::    IA0000, IA0X00, IA0Y00, IA0Z00,                     &
     &              IAXX00, IAXY00, IAXZ00, IAYY00,                     &
     &              IAYZ00, IAZZ00, IA000X, IA000Y,                     &
     &              IA000Z, IA00XX, IA00XY, IA00XZ,                     &
     &              IA00YY, IA00YZ, IA00ZZ, IA0X0X,                     &
     &              IA0X0Y, IA0X0Z, IA0Y0X, IA0Y0Y,                     &
     &              IA0Y0Z, IA0Z0X, IA0Z0Y, IA0Z0Z

      COMMON /ADER/ IA0000, IA0X00, IA0Y00, IA0Z00,                     &
     &              IAXX00, IAXY00, IAXZ00, IAYY00,                     &
     &              IAYZ00, IAZZ00, IA000X, IA000Y,                     &
     &              IA000Z, IA00XX, IA00XY, IA00XZ,                     &
     &              IA00YY, IA00YZ, IA00ZZ, IA0X0X,                     &
     &              IA0X0Y, IA0X0Z, IA0Y0X, IA0Y0Y,                     &
     &              IA0Y0Z, IA0Z0X, IA0Z0Y, IA0Z0Z
