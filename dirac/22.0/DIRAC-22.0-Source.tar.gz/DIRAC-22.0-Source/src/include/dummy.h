!     make DUMMY write protected (on most computers)
      REAL*8 DUMMY
      INTEGER IDUMMY,IDUMMYARR(1:1)
      PARAMETER (DUMMY = 1.0D20, IDUMMY = -9999999)
      PARAMETER (IDUMMYARR = -9999999)
