      REAL*8          SPRNUC(3,3,MXCENT),SPRNUC2(3,3,MXCENT),
     &                SPRNUC3(3,3,MXCENT),SPRDNL(3,3,MXCENT),
     &                GTRANT(3,3,MXCENT)

      LOGICAL         LINDET

      COMMON /SPINRO/ SPRNUC, SPRNUC2, SPRNUC3, SPRDNL,
     &                GTRANT, LINDET
