dirac_mointegral_export.x test
==============================

Simple test of the standalone executable "dirac_mointegral_export.x".

  pam --noarch --inp=BeH.x2c_scf_relcc.inp  --mol=BeH.sto-2g.lsym.mol --get "MDCINT MRCONEE"

