Modern input reading
====================

Recommended input reader for DIRAC, please read the corresponding part of
the DIRAC manual (diracprogram.org).
