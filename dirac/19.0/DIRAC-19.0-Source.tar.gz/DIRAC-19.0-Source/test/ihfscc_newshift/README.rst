!
! Test on new feature - better shift in the IH-FSCC method, done by E.Eliav and A.Zaitsevskii
!


