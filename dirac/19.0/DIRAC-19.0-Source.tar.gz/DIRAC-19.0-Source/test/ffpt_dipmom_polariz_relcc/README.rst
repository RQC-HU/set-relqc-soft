Calculation of open-shell molecule electric properties (dipole moment, polarizability).
See the corresponding web-manual, which is refering to this test.
