!     FILE : thrzer.h
      REAL*8 THRZER
      PARAMETER (THRZER = 1.0D-14)
