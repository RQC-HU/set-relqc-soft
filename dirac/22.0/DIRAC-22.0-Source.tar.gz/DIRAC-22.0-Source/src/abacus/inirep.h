C
CMI  from dalton for subroutine POLPRI
      INTEGER  NREPPI(3), IREPPI(3,3)
      COMMON /INIREP/ NREPPI, IREPPI
