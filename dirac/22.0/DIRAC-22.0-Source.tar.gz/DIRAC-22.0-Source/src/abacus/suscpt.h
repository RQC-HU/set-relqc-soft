CMI   COMMON /SUSCPT/ SUSDIA(3,3), SUS2EL(3,3), SUSFS(3,3), SUSREL(3,3),
CMI  &                SUSTOT(3,3), SUSFSY(3,3)
CMI ... substitution by common the block dcbsusc.h

#include "dcbsusc.h"
