C
C
C     Real or approximate boson symmetry of orbitals.
C     
C     Depends on maxorb.h
C
      COMMON /DCIBOS/ IBOSYM(MXCORB)
