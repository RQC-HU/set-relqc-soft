!    This is for the argos routine
      CHARACTER*3 itypag(0:7)
      COMMON /argoscomch/ itypag
