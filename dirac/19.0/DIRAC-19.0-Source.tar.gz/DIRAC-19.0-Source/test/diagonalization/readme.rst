Diagonalization routines in DIRAC
=================================

This brief test is aimed for checking diagonalization
routines in DIRAC via the utils/diag.F90 standalone
executable.

The input file is DIAGONALIZE_TESTS.INP. The program reads testing
matrix "Jz_SS_matrix.fermirp2-2".


