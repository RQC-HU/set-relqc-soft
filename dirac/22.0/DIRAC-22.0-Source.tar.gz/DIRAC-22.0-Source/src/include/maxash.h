!
! FILE    : maxash.h
!
!     MAXASH = maximum number of active orbitals in KR-MCSCF
!
      INTEGER MAXASH
      PARAMETER (MAXASH = 300)
