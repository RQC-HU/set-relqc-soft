! FILE mxsymm.h

!     mxsymm.h - for symmetry detection (values set and used in hersym.F)

      REAL*8  TOLLRN, TOLLRN_2, ZERTOL
      INTEGER MAXAXS, MAXMIR,   IPRSYM

      COMMON /MXSYMM/ TOLLRN, TOLLRN_2, ZERTOL, MAXAXS, MAXMIR, IPRSYM

! -- end of mxsymm.h --
