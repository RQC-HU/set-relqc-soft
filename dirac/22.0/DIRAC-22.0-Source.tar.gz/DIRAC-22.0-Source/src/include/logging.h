      logical logmemget
      common /logcb/ logmemget
