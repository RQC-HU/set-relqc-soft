C----- bit manipulation definitions
#include <ibtpar.h>
#include <ibtfun.h>
C-----
