:orphan:
 

MOLTRA:Sample inputs
=====================

Use all spinors with energies between -12.0 and 20.0 a.u. as active
space. Note that one may *not* place a comment line directly after
.ACTIVE:

::

    **MOLTRA
    .ACTIVE
    energy -12.0 20.0 1.0


