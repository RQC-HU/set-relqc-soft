      LOGICAL         DC101, DC1H1, DC1E1, DC2H1, DC2E1,
     *                DC102, DC1H2, DC1E2, DC2H2, DC2E2,
     *                DPATH1, DPATH2
      COMMON /SUBDIR/ DC101, DC1H1, DC1E1, DC2H1, DC2E1,
     *                DC102, DC1H2, DC1E2, DC2H2, DC2E2,
     *                DPATH1, DPATH2, NTOTAL
