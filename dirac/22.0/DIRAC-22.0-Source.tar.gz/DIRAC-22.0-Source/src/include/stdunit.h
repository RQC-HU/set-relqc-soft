      integer, parameter :: istderr = 0
      integer, parameter :: istdin  = 5
      integer, parameter :: istdout = 6
