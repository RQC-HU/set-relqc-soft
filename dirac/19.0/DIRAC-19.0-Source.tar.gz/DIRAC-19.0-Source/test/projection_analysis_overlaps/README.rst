Projection analysis with overlaps
=================================

Let us have the PF5 molecule (point symmetry D3h, computational symmetry C2v).
The projection analysis is carried in terms of the P,F
atomic fragments.

The printout of overlaps matrices together
with some kind of gross overlap populations between atomic fragments is activated.

This is purely experimental feature.

