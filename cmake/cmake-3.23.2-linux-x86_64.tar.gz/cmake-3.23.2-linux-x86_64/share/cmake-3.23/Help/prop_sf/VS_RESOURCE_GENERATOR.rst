VS_RESOURCE_GENERATOR
---------------------

.. versionadded:: 3.8

This property allows to specify the resource generator to be used
on this file. It defaults to ``PublicResXFileCodeGenerator`` if
not set.

This property only applies to C# projects.
