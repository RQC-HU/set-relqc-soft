This test checks the functionality of MP2 natural orbitals in Dirac for various symmetries. 
MP2-NOs can be used as starting orbitals for example for CC or CI or MCSCF. 
