This test contains various "exotic" geometries of light atoms molecular systems
and is solely aimed to test the basis set input reader.

Likewise such a system is expected to give converged x2c-SCF energy.

Geometry types:
----------------
 A -- B  -- B 

 A -- B  -- B -- B

 A -- A  -- B -- B


 ...add more ...
