      COMMON /GDVEC/ NGDTOT(2), NGDVEC(8,2), IGDCOR(MXCOOR+3,8,2),
     &               IGDREC(MXCOOR+3,8,2), NTRVEC(8),
     &               ITRCOR(10*MXCENT,8), ITRREC(10*MXCENT,8),
     &               IDORCT(80*MXCENT), IDORCI(24*(MXCENT + 1),2)
