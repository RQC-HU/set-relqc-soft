*Comdeck dofuc $Revision$
      double precision df(0:ndfmx),dffrac(0:ndfmx,0:ndfmx) 
      common /dofuc/ df,dffrac
cbs   some double facultatives and their fractions are given on this block
cbs   the whole arrays are initialized by inidf 
