C     Definitions for IBNDX; JBCNDX for CI-type, JBONDX for orb-type
      PARAMETER (JBCNDX=-1, JBONDX=1)
