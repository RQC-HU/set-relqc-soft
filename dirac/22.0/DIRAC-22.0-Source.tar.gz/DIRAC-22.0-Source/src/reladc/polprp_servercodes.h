#define SERVER_HELLO    01
#define SERVER_PRECON   12
#define SERVER_VOVV     20
#define SERVER_VVVV     30
#define SERVER_MATDIS   34
#define SERVER_MATMUL   35
#define SERVER_DONE     40

#define MSGN            555

#define SERVER_TRACE    0
