      CHARACTER*1 CHRXYZ(-3:3)
      DATA CHRXYZ /'z','y','x',' ','X','Y','Z'/
