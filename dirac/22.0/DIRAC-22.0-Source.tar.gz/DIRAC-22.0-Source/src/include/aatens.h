      real(8)         AATNUC,           AATORB,                         &
     &                AATCI,            AAT2ND,                         &
     &                AATTOT
      COMMON /AATENS/ AATNUC(3,MXCOOR), AATORB(3,MXCOOR),               &
     &                AATCI (3,MXCOOR), AAT2ND(3,MXCOOR),               &
     &                AATTOT(3,MXCOOR)
