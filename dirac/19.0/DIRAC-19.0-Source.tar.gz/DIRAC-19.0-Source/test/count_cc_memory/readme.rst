Test aimed at  counting the (MOLTRA+)RelCC memory demand.
See the web documentation.

