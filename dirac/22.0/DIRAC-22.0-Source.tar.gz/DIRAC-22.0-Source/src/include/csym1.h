      integer :: length, indmax, ibuf
      real(8) :: buf
      COMMON /CSYM1/ BUF(600), IBUF(600), LENGTH, INDMAX
