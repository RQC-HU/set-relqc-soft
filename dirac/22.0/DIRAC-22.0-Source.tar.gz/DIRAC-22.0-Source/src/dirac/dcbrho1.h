C*** 1-dimensional density plot ***
      COMMON/CBRHO1/DSTEP,IPRHO1
      COMMON/CBIRHO1/IOPTDD
