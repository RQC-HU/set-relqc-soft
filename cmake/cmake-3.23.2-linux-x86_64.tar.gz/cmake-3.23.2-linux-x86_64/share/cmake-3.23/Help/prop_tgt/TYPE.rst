TYPE
----

The type of the target.

This read-only property can be used to test the type of the given
target.  It will be one of ``STATIC_LIBRARY``, ``MODULE_LIBRARY``,
``SHARED_LIBRARY``, ``OBJECT_LIBRARY``, ``INTERFACE_LIBRARY``, ``EXECUTABLE``
or one of the internal target types.
