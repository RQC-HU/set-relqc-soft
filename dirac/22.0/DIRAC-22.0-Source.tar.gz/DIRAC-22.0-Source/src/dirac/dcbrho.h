C*** 3-dimensional density plot ***
C     NCUBORB - number of g/u orbitals to make cubes of
C     ICUBORB - which orbitals to make cubes from
      COMMON/CBRRHO/ILSCUB,IPRRHO,NCUBE(0:3),CUBADJ(2),ICUBORB(1000,2),
     &     NCUBORB(2)


