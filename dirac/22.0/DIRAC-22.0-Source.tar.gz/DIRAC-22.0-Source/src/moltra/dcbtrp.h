C*****************************************************************************
C  DCBTRP:  Property opearators to be transformed to MO-basis
C
      PARAMETER(MAXTRP=350)
      COMMON/DCBTRP/IPRTRP,NTRPP,LTRPP(MAXTRP)

