!     Labels for vector types:
!       JBCNDX for CI-type,
!       JBENDX for electron orb-type, 
!       JBPNDX for positron orb-type
      INTEGER JBCNDX, JBENDX, JBPNDX
      PARAMETER (JBCNDX = -1, JBENDX = 1, JBPNDX = 2)
