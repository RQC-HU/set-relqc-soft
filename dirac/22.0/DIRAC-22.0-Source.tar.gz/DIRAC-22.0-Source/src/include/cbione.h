      integer         IPRINT, MAXDIF, IDATOM, IDCOOR
      LOGICAL         SKIP, DIFINT, NODC, NODV, DIFDIP, CUT
      COMMON /CBIONE/ IPRINT, SKIP, MAXDIF, IDATOM,                     &
     &                IDCOOR, DIFINT, NODC, NODV, DIFDIP, CUT
