:orphan:
  
Openfermion-Dirac
=================

OpenFermion is a package for Quantum simulation. Dirac has been interfaced with OpenFermion through a python interface, that can be downloaded here https://github.com/bsenjean/Openfermion-Dirac/.
A jupyter-notebook tutorial is accessible at https://github.com/bsenjean/Openfermion-Dirac/tree/master/tutorial.
