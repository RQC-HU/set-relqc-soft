      COMMON /CRELOP/ PI,ZWP,SQPI,VELIT,PREA,CSQ,ZWPH32,FAK(26),               
     *ZWPH12,BCO(210),GA(20)                                              
      SAVE /CRELOP/
