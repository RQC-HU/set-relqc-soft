2P state of fluorine
=====================

This test calculates the 2P state of fluorine,
using the spinfree formalism different Hamiltonians.

One of them - the DKH2sfB Hamiltonian - is given here in the form 
to be fully comparable with the DALTON scalar relativistic Hamiltonian counterpart.

The DIRAC SCF method utilizes the BOSONSELECTION key to get open-shell
occupation identical with the DALTON program.
