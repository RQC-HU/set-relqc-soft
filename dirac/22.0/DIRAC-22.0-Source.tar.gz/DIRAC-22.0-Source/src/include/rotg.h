      REAL*8          GFANUC(3,3)

      LOGICAL         LINDET

      COMMON /ROTG/ GFANUC,LINDET
