Block-diagonalizing transformation
===================================

This is quick test for an experimental feature - block diagonalizing transformation of the Dirac Hamitlonian
with the generalized Jacobi block-diagonalization of quaternion matrixes.

Test "bss_blockd.ci.inp, Z86_Flike.mol" deactivated due to numerical instabilities.
