!
!     Memory initialization
!     =====================
!
      KWORK = 1
      KFREE = KWORK
      LFREE = LWORK
