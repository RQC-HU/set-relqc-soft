      CHARACTER*1 CHRSGN(-1:1)
      DATA CHRSGN /'-',' ','+'/
