ECP testing calculations
========================

See the tutorial.
