The pam script test
===================

This is DIRAC pam script test as enabled by runtest-in-DIRAC library by Rado Bast, https://github.com/bast/runtest.

Beyond testing pam in parallel mode it also checks the open-shell SCF setting.


