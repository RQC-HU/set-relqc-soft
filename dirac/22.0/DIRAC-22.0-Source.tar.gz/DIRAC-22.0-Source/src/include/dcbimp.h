!----------------------------------------------------------------------!
!
!     variables needed for the MO import
!
!----------------------------------------------------------------------!
      LOGICAL :: DOIMPMOS
      CHARACTER(LEN=64) :: QCPACK, FILIMP(2)

      COMMON / DCBIMP / DOIMPMOS, QCPACK, FILIMP
