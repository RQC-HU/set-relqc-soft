      real(8)         DIP0,    DIP1,           DIPFLT,                  &
     &                POLARS,      POLFLT,      DIPLF0,    QAPT
      COMMON /MOLDIP/ DIP0(3), DIP1(3,MXCOOR), DIPFLT(3,MXCOOR),        &
     &                POLARS(3,3), POLFLT(3,3), DIPLF0(3), QAPT(MXCENT)
