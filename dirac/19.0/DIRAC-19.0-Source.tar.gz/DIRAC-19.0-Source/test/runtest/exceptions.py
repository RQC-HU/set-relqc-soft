class FilterKeywordError(Exception):
    pass


class FailedTestError(Exception):
    pass


class BadFilterError(Exception):
    pass
