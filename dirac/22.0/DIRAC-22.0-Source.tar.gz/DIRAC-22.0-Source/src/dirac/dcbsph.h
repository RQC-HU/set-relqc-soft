C*** Spherical transformation
#include <sphtrm.h>
      COMMON/SPCTRM/SPC(NCSP)
