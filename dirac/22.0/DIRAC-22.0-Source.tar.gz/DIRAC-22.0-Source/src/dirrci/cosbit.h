!
! FILE    : cosbit.h
! AUTHOR  : sya
! PURPOSE : a table of 1-byte integer to speed counting bits in a
!           4-byte integer
! 
!*** COSCI calculations ***
      INTEGER IBTAB1(0:255)
      COMMON /DCIBIT0/ IBTAB1
