C*** Parameters for index packing ***
      COMMON/INDPCK/NBITS,NIBUF,NBIT1,NBIT2,IBIT1,IBIT2
