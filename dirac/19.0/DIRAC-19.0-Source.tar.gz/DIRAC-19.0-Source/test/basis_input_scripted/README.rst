See the corresponding web-manual, ../../doc/programmers/test_basis_sets.rst
