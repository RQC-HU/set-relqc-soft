Directory with working input and output files for the UF6 tutorial.

See the corresponding part of the documentation, where the UF6 case study
is explained.
